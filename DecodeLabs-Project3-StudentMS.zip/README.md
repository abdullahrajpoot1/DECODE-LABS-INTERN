
# DecodeLabs Project 3 - Database Integration

Professional Student Management System API

## Technologies
- Node.js
- Express.js
- MongoDB Atlas
- Mongoose

## Features
- Create Student
- Read Students
- Update Student
- Delete Student
- MongoDB Integration
- REST API

## Setup

1. npm install
2. Add MongoDB Atlas URI in .env
3. npm start

## Endpoints

GET /api/students
GET /api/students/:id
POST /api/students
PUT /api/students/:id
DELETE /api/students/:id

Example POST Body:
{
"name":"Abdullah",
"email":"abdullah@gmail.com",
"course":"BSCS",
"age":22
}
