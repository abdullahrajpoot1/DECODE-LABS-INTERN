
const express = require('express');
const router = express.Router();
const controller = require('../controllers/studentController');
const validate = require('../middleware/validateStudent');

router.get('/', controller.getAllStudents);
router.get('/:id', controller.getStudentById);
router.post('/', validate, controller.createStudent);
router.put('/:id', controller.updateStudent);
router.delete('/:id', controller.deleteStudent);

module.exports = router;
