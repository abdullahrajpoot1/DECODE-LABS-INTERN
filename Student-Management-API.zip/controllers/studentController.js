
const students = require('../data/students.json');

exports.getAllStudents = (req,res)=>{
  res.json({success:true,data:students});
};

exports.getStudentById = (req,res)=>{
  const student = students.find(s=>s.id===parseInt(req.params.id));
  if(!student) return res.status(404).json({success:false,message:'Student not found'});
  res.json({success:true,data:student});
};

exports.createStudent = (req,res)=>{
  const {name,email,course} = req.body;
  const newStudent = {
    id: students.length + 1,
    name,email,course
  };
  students.push(newStudent);
  res.status(201).json({success:true,data:newStudent});
};

exports.updateStudent = (req,res)=>{
  const student = students.find(s=>s.id===parseInt(req.params.id));
  if(!student) return res.status(404).json({success:false,message:'Student not found'});

  student.name = req.body.name || student.name;
  student.email = req.body.email || student.email;
  student.course = req.body.course || student.course;

  res.json({success:true,data:student});
};

exports.deleteStudent = (req,res)=>{
  const index = students.findIndex(s=>s.id===parseInt(req.params.id));
  if(index===-1) return res.status(404).json({success:false,message:'Student not found'});

  students.splice(index,1);
  res.json({success:true,message:'Student deleted'});
};
