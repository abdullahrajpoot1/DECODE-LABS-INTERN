
# Student Management API

Real-life backend project for DecodeLabs Internship.

## Features
- MVC Architecture
- GET All Students
- GET Student By ID
- Create Student
- Update Student
- Delete Student
- Input Validation
- JSON Responses

## Installation
npm install
npm start

## API Endpoints

GET /api/students

GET /api/students/:id

POST /api/students
{
  "name":"Abdullah",
  "email":"abdullah@example.com",
  "course":"BSCS"
}

PUT /api/students/:id

DELETE /api/students/:id
