
module.exports = (req,res,next)=>{
 const {name,email,course} = req.body;
 if(!name || !email || !course){
   return res.status(400).json({
      success:false,
      message:'name, email and course are required'
   });
 }
 next();
};
