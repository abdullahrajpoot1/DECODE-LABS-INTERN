
const express = require('express');
const studentRoutes = require('./routes/studentRoutes');

const app = express();
app.use(express.json());

app.use('/api/students', studentRoutes);

app.get('/', (req,res)=>{
  res.json({message:'Student Management API Running'});
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log(`Server running on ${PORT}`));
